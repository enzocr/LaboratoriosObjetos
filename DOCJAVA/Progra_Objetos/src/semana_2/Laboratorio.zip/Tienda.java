package Semana2;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author Enzo Quartino Zamora
 */
public class Tienda {

    /**
     * Nombre de la tienda
     */
    private String nombreTienda;
    /**
     * Direccion de la tienda
     */
    private String direccionTienda;
    /**
     * Cedula juridica de la tienda
     */
    private String cedulaTienda;
    /**
     * Array List de los datos de los clientes
     */

    private ArrayList<Cliente> listaClientes = new ArrayList<>();
    /**
     * Array List de los datos de los videos
     */
    private ArrayList<Video> listaVideos = new ArrayList<>();

    /**
     *Retorna el nombre de la tienda registrada
     * @return nombreTienda
     */
    public String getNombreTienda() {
        return nombreTienda;
    }

    /**
     *fija el parametro nombreTienda  en el atributo nombreTienda
     * de la Clase Tienda
     * @param nombreTienda
     */
    public void setNombreTienda(String nombreTienda) {
        this.nombreTienda = nombreTienda;
    }

    /**
     *Retorna la direccion de la tienda registrada
     * @return direccionTienda
     */
    public String getDireccionTienda() {
        return direccionTienda;
    }

    /**
     *fija el parametro direccionTienda en el atributo direccionTienda
     * de la Clase Tienda
     * @param direccionTienda
     */
    public void setDireccionTienda(String direccionTienda) {
        this.direccionTienda = direccionTienda;
    }

    /**
     *Retorna la cedula juridica de la tienda
     * @return cedulaTienda
     */
    public String getCedulaTienda() {
        return cedulaTienda;
    }

    /**
     *fija el parametro cedulaTienda en el atributo cedulaTienda
     * de la Clase Tienda
     * @param cedulaTienda
     */
    public void setCedulaTienda(String cedulaTienda) {
        this.cedulaTienda = cedulaTienda;
    }

    /**
     *Retorna el array list listaClientes
     * @return listaClientes
     */
    public ArrayList<Cliente> getListaClientes() {
        return listaClientes;
    }

    /**
     *fija el parametro listaClientes en el atributo listaClientes
     * de la Clase Tienda
     * @param listaClientes
     */
    public void setListaClientes(ArrayList<Cliente> listaClientes) {
        this.listaClientes = listaClientes;
    }

    /**
     *Retorna el array list listaVideos
     * @return listaVideos
     */
    public ArrayList<Video> getListaVideos() {
        return listaVideos;
    }

    /**
     *fija el parametro listaVideos  en el atributo listaVideos
     * de la Clase Tienda
     * @param listaVideos
     */
    public void setListaVideos(ArrayList<Video> listaVideos) {
        this.listaVideos = listaVideos;
    }

    /**
     * Se crea una variable de clase Video
     * Se reciben 3 parametros de tipo String y se fijan en el tipo, titulo
     * y ID del video, luego se agregan al Array List listaVideos
     * @param pTipo
     * @param pTitulo
     * @param pId
     */
    public void registrarVideo(String pTipo, String pTitulo, String pId) {
        Video miVideo = new Video();
        miVideo.setTipo(pTipo);
        miVideo.setTitulo(pTitulo);
        miVideo.setiD(pId);
        listaVideos.add(miVideo);

    }

    /**
     *Se crea una variable de clase Cliente
     * Se reciben 4 parametros de tipo String y uno de tipo LocalDate y se fijan
     * en sus respectivos atributos, luego se agregan al Arrat List listaClientes
     * @param nombre
     * @param cedula
     * @param direccion
     * @param fecha
     * @param contrato
     */
    public void registrarCliente(String nombre, String cedula, String direccion, LocalDate fecha, String contrato) {
        Cliente miCliente = new Cliente();
        miCliente.setCedulaCliente(cedula);
        miCliente.setDireccionCliente(direccion);
        miCliente.setNombreCliente(nombre);
        miCliente.setToday(LocalDate.now());
        miCliente.setNumContratoCliente(contrato);
        listaClientes.add(miCliente);

    }

    /**
     *Recibe un parametro de tipo String
     * @param pTitulo es el titulo del video
     * @return un entero, si es un -1 quiere decir que ya esta agregado, si es
     * un 1 si se puede agregar
     *
     */
    public int comprobarVideo(String pTitulo) {

        for (int i = 0; i < listaVideos.size(); i++) {

            if (pTitulo.equals(listaVideos.get(i).getTitulo())) {

                return -1;
            }
        }

        return 1;
    }

    /**
     *Recibe un parametro de tipo String
     * @param pNumeroCedulaCliente cedula de identifiacion del cliente
     * @return un entero, si es un -1 quiere decir que ya esta agregado, si es
     * un 1 si se puede agregar
     *
     */
    public int comprobarCedulaCliente(String pNumeroCedulaCliente) {
        for (int i = 0; i < listaClientes.size(); i++) {

            if (pNumeroCedulaCliente.equals(listaClientes.get(i).getCedulaCliente())) {
                return -1;

            }

        }
        return 1;
    }

    /**
     *Recibe 3 parametros de tipo String y se fijan en sus atributos respectivos
     * de la tienda
     * @param nombre
     * @param cedula
     * @param direccion
     */
    public void registrarTienda(String nombre, String cedula, String direccion) {

        nombreTienda = nombre;
        cedulaTienda = cedula;
        direccionTienda = direccion;

    }

}
