package Semana2;

import java.time.LocalDate;

/**
 *
 * @author Enzo Quartino Zamora
 */
public class Cliente {

    /**
     * Nombre del cliente ingresado
     */
    private String nombreCliente;

    /**
     * Direccion del cliente, ingresado
     */
    private String direccionCliente;

    /**
     * Cedula de identificacion del cliente, ingresado
     */
    private String cedulaCliente;

    /**
     * Fecha siempre sera el dia actual de ingreso del cliente al sistema
     */
    private LocalDate today;

    /**
     * Numero de contrato que tendra el cliente con la tienda
     */
    private String numContratoCliente;

    /**
     * returna el nombre del cliente
     *
     * @return nombre del cliente
     */
    public String getNombreCliente() {
        return nombreCliente;
    }

    /**
     * fija el parametro nombreCliente en el atributo nombreCliente de la Clase
     * Cliente
     *
     * @param nombreCliente
     */
    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    /**
     * retorna direccion de cliente
     *
     * @return direccion del cliente
     */
    public String getDireccionCliente() {
        return direccionCliente;
    }

    /**
     * fija el parametro nombreCliente en el atributo nombreCliente de la Clase
     * Cliente
     *
     * @param direccionCliente
     */
    public void setDireccionCliente(String direccionCliente) {
        this.direccionCliente = direccionCliente;
    }

    /**
     * retorna el numero de cedula del cliente
     *
     * @return cedulaCliente
     */
    public String getCedulaCliente() {
        return cedulaCliente;
    }

    /**
     * fija el parametro cedulaCliente en el atributo cedulaCliente de la Clase
     * Cliente
     *
     * @param cedulaCliente
     */
    public void setCedulaCliente(String cedulaCliente) {
        this.cedulaCliente = cedulaCliente;
    }

    /**
     * retorna la fecha en la que se inscribio al cliente
     *
     * @return today
     */
    public LocalDate getToday() {
        return today;
    }

    /**
     * fija el parametro today en el atributo today de la Clase Cliente
     *
     * @param today
     */
    public void setToday(LocalDate today) {
        this.today = today;
    }

    /**
     * retorna el numero de contrato del cliente
     *
     * @return numContratoCliente
     */
    public String getNumContratoCliente() {
        return numContratoCliente;
    }

    /**
     * fija el parametro numContratoCliente en el atributo numContratoCliente de
     * la Clase Cliente
     *
     * @param numContratoCliente
     */
    public void setNumContratoCliente(String numContratoCliente) {
        this.numContratoCliente = numContratoCliente;
    }

}
