package Laboratorio3;

import java.util.ArrayList;

/**
 *
 *
 * @author Enzo Quartino Zamora
 */
public class Clinica {

    private String nombreClinica;
    private String cedulaClinica;
    private String direccionClinica;
    private String telefonoClinica;
    private ArrayList<Medico> listaMedicos;
    private ArrayList<Paciente> listaPacientes;

    /**
     * Inicializa atributos por defecto
     */
    public Clinica() {
        this.listaMedicos = new ArrayList<>();
        this.listaPacientes = new ArrayList<>();
        nombreClinica = "";
        cedulaClinica = "";
        direccionClinica = "";
        telefonoClinica = "";

    }

    /**
     * Inicializa atributos por los valores pasados por parametro
     *
     * @param pNombre
     * @param pCedula
     * @param pDireccion
     * @param pTel
     */
    public Clinica(String pNombre, String pCedula, String pDireccion, String pTel) {
        this.listaMedicos = new ArrayList<>();
        this.listaPacientes = new ArrayList<>();
        nombreClinica = pNombre;
        cedulaClinica = pCedula;
        direccionClinica = pDireccion;
        telefonoClinica = pTel;

    }

    /**
     *
     * @return nombreClinica
     */
    public String getNombreClinica() {
        return nombreClinica;
    }

    /**
     * Fija el nombre de la clinica
     *
     * @param nombreClinica
     */
    public void setNombreClinica(String nombreClinica) {
        this.nombreClinica = nombreClinica;
    }

    /**
     *
     * @return cedulaClinica
     */
    public String getCedulaClinica() {
        return cedulaClinica;
    }

    /**
     * Fija la cedula de la Clinica
     *
     * @param cedulaClinica
     */
    public void setCedulaClinica(String cedulaClinica) {
        this.cedulaClinica = cedulaClinica;
    }

    /**
     *
     * @return direccionClinica
     */
    public String getDireccionClinica() {
        return direccionClinica;
    }

    /**
     * Fija la direccion de la clinica
     *
     * @param direccionClinica
     */
    public void setDireccionClinica(String direccionClinica) {
        this.direccionClinica = direccionClinica;
    }

    /**
     *
     * @return telefonoClinica
     */
    public String getTelefonoClinica() {
        return telefonoClinica;
    }

    /**
     * Fija el telefono de la clinica
     *
     * @param telefonoClinica
     */
    public void setTelefonoClinica(String telefonoClinica) {
        this.telefonoClinica = telefonoClinica;
    }

    /**
     *
     * @return datos registrados de la clinica
     */
    @Override
    public String toString() {
        return "Clinica{" + "nombreClinica=" + nombreClinica
                + ", cedulaClinica=" + cedulaClinica
                + ", direccionClinica=" + direccionClinica
                + ", telefonoClinica=" + telefonoClinica + '}';
    }

    /**
     * Registra los datos enviados por el usuario como parametro
     *
     * @param codigo codigo del medico
     * @param nombre nombre del medico
     * @param email correo electronico del medico
     * @param especialidad especialidad del medico
     * @param telefono telefono del medico
     * @param cedula cedula de identificacion del medico
     */
    public void registrarMedico(String codigo, String nombre, String email, String especialidad, String telefono, String cedula) {
        Medico elMedico = new Medico(codigo, nombre, email, especialidad, telefono, cedula);
        listaMedicos.add(elMedico);

    }

    /**
     * Registra los datos enviados por el usuario como parametro
     *
     * @param cedula cedula del paciente
     * @param nombre nombre del paciente
     * @param direccion direccion del paciente
     * @param email correo electronico del paciente
     * @param telefono telefono del paciente
     */
    public void registrarPaciente(String cedula, String nombre, String direccion, String email, String telefono) {
        Paciente elPaciente = new Paciente(cedula, nombre, direccion, email, telefono);
        listaPacientes.add(elPaciente);

    }

    /**
     *
     * método que devuelve un arreglo en cada posición, la información del
     * método con el toString de la clase.
     *
     * @return arreglo de Strings llamado medicos
     */
    public String[] getMedicos() {
        int size = this.listaMedicos.size();
        String[] medicos = new String[size];
        int i = 0;
        for (Medico elMedico : listaMedicos) {
            medicos[i] = elMedico.toString();
            i++;

        }

        return medicos;
    }

    /**
     *
     * método que devuelve un arreglo en cada posición, la información del
     * método con el toString de la clase.
     *
     * @return arreglo de Strings llamado pacientes
     */
    public String[] getPacientes() {
        int size = this.listaPacientes.size();
        String[] pacientes = new String[size];
        int i = 0;
        for (Paciente elPaciente : listaPacientes) {
            pacientes[i] = elPaciente.toString();
            i++;
        }
        return pacientes;
    }

}
