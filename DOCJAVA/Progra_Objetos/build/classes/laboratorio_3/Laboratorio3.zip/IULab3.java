package Laboratorio3;

import java.io.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Enzo Quartino Zamora
 */
public class IULab3 {

    static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    static PrintStream out = System.out;
    static Clinica laClinica = new Clinica();

    /**Muestra el main del sistema
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        int opc;

        do {
            mostrarMenu();
            opc = leerOpcion();
            ejecutarAccion(opc);
        } while (opc != 5);
    }

    /**
     *Imprime opciones posibles para realizar
     * @throws IOException
     */
    public static void mostrarMenu() throws IOException {

        out.println();
        out.println("-----BIENVENIDO-----");
        out.println("1.  Registrar medicos");
        out.println("2.  Listar medicos");
        out.println("3.  Registrar pacientes");
        out.println("4.  Listar pacientes");
        out.println("5.  Salir");

        out.println();
    }

    /**
     *Retorna la opcion digitada por el usuario
     * @return opcion
     * @throws IOException
     */
    public static int leerOpcion() throws IOException {

        int opcion;

        opcion = Integer.parseInt(JOptionPane.showInputDialog("Seleccione accion a realizar"));

        return opcion;
    }

    /**
     *Pasa la opcion digitada por el usuario a un switch y se llama a su
     * determinado metodo
     *
     * @param pOpcion
     * @throws IOException
     */
    public static void ejecutarAccion(int pOpcion) throws IOException {

        switch (pOpcion) {

            case 1:
                datosMedico();
                break;

            case 2:
                listarMedicos();
                break;

            case 3:
                datosPaciente();
                break;

            case 4:
                listarPacientes();
                break;

            case 5:
                out.println("Gracias por usar el sistema");
                break;

            default:
                out.println("Opcion invalida");

        }

    }

    /**
     *Se ingresan los datos del medico, y se envian como parametro, a registrar
     * @throws IOException
     */
    public static void datosMedico() throws IOException {

        String codigo, nombre, email, especialidad, telefono, cedula;

        out.println("Ingrese el codigo del medico");
        codigo = in.readLine();
        out.println("Ingrese el nombre del medico");
        nombre = in.readLine();
        out.println("Ingrese el email del medico");
        email = in.readLine();
        out.println("Ingrese la especialidad del medico");
        especialidad = in.readLine();
        out.println("Ingrese el telefono del medico");
        telefono = in.readLine();
        out.println("Ingrese la cedula del medico");
        cedula = in.readLine();

        laClinica.registrarMedico(codigo, nombre, email, especialidad, telefono, cedula);

    }

    /**
     *Se ingresan los datos del paciente y se envian como parametros, a registrar
     * @throws IOException
     */
    public static void datosPaciente() throws IOException {
        String cedula, nombre, direccion, email, telefono;
        out.println("Ingrese la cedula del paciente");
        cedula = in.readLine();
        out.println("Ingrese el nombre del paciente");
        nombre = in.readLine();
        out.println("Ingrese el direccion del paciente");
        direccion = in.readLine();
        out.println("Ingrese el email del paciente");
        email = in.readLine();
        out.println("Ingrese el telefono del paciente");
        telefono = in.readLine();

        laClinica.registrarPaciente(cedula, nombre, direccion, email, telefono);
    }

    /**
     *Imprime los medicos registrados
     * @throws IOException
     */
    public static void listarMedicos() throws IOException {
        for (int i = 0; i < laClinica.getMedicos().length; i++) {

            out.println("MEDICO # " + (i));
            out.println(laClinica.getMedicos()[i]);
            out.println("********************");
        }
    }

    /**
     *Imprime los pacientes registrados
     * @throws IOException
     */
    public static void listarPacientes() throws IOException {
        for (int i = 0; i < laClinica.getPacientes().length; i++) {

            out.println("Paciente # " + (i));
            out.println(laClinica.getPacientes()[i]);
            out.println("********************");
        }
    }

}
